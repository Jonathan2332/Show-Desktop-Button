import GObject from 'gi://GObject';
import St from 'gi://St';
import Clutter from 'gi://Clutter';
import Meta from 'gi://Meta';
import Shell from 'gi://Shell';
import GLib from 'gi://GLib';
import Gio from 'gi://Gio';

import * as Main from 'resource:///org/gnome/shell/ui/main.js';
import * as PanelMenu from 'resource:///org/gnome/shell/ui/panelMenu.js';
import * as DateMenu from 'resource:///org/gnome/shell/ui/dateMenu.js';
import { Extension } from 'resource:///org/gnome/shell/extensions/extension.js';

const ShowDesktopButton = GObject.registerClass(
class ShowDesktopButton extends PanelMenu.Button {
	_init(extension) {
		super._init(0.0, extension.metadata.name, true);
		this._extension = extension;
		this._timerId = 0;

		const settings = extension.getSettings();
		const padding = settings.get_int('indicator-padding');

		if (settings.get_boolean('show-icon')) {
			let iconPath = settings.get_string('indicator-icon-name');
			let iconBaseName = GLib.path_get_basename(iconPath);
			let iconName = iconBaseName.slice(0, iconBaseName.lastIndexOf('.'));
			
			const icon = new St.Icon({
				icon_name: iconName,
				style_class: 'system-status-icon',
				style: `margin-left: ${padding}px; margin-right: ${padding}px;`,
			});
			this.add_child(icon);
		} else {
			const box = new St.Bin({
				style: `width: ${padding * 2}px; min-height: 1px;`,
			});
			this.add_child(box);
		}
		
		this.connect('button-release-event', () => {
			this._clearTimer();
			this._extension.toggleDesktop();
			return Clutter.EVENT_STOP;
		});

		this.connect('notify::hover', () => {
			const settings = this._extension.getSettings();
			if (!settings.get_boolean('hover-preview')) return;
			if (this.hover) {
				this._clearTimer();
				const previewDelay = settings.get_int('hover-delay');
				this._timerId = GLib.timeout_add(GLib.PRIORITY_DEFAULT, previewDelay, () => {
					this._extension.logDebug("Hover timeout triggered");
					this._extension.previewDesktop(true);
					this._timerId = 0;
					return GLib.SOURCE_REMOVE;
				});
			} else {
				this._clearTimer();
				this._extension.previewDesktop(false);
			}
		});
	}
	
	_clearTimer() {
		if (this._timerId > 0) {
			GLib.source_remove(this._timerId);
			this._timerId = 0;
		}
	}
	
	destroy() {
		this._clearTimer();
		super.destroy();
	}
});

export default class ShowDesktopExtension extends Extension {
	enable() {
		this._settings = this.getSettings();
		this._systemSettings = new Gio.Settings({ schema_id: 'org.gnome.desktop.wm.keybindings' });
		this._signals = [];

		this._debugEnabled = this.metadata['debug'] === true;
		
		this.logDebug("Extension enabled - Logging is active");

		this._signals.push(
			this._settings.connect('changed::indicator-position', () => this._refreshIndicator()),
			this._settings.connect('changed::indicator-icon-name', () => this._refreshIndicator()),
			this._settings.connect('changed::show-icon', () => this._refreshIndicator()),
			this._settings.connect('changed::indicator-padding', () => this._refreshIndicator())
		);

		this._refreshIndicator();

		const systemShortcut = this._systemSettings.get_strv('show-desktop');

		if (systemShortcut.length > 0) {
			this._settings.set_strv('show-desktop-shortcut', systemShortcut);
		}

		Main.wm.addKeybinding(
			'show-desktop-shortcut',
			this._settings,
			Meta.KeyBindingFlags.IGNORE_AUTOREPEAT,
			Shell.ActionMode.NORMAL | Shell.ActionMode.OVERVIEW | Shell.ActionMode.POPUP,
			() => {
				this.logDebug("Extension shortcut pressed");
				this.toggleDesktop();
			}
		);
	}

	logDebug(message) {
		if (this._debugEnabled) {
			console.warn(`[Show-Desktop-Debug] ${message}`);
		}
	}

	_refreshIndicator() {
		this.logDebug("Refreshing Indicator UI");
		if (this._indicator) {
			this._indicator.destroy();
			this._indicator = null;
		}

		this._indicator = new ShowDesktopButton(this);

		const position = ['left', 'left', 'center', 'center', 'right', 'right'];
		const qualifier = [0, 1, 0, 1, 1, -1];
		const index = this._settings.get_enum('i');

		const centerBox = Main.panel._centerBox;
    	const centerBoxChildren = centerBox.get_children();

	    const dateMenuIndex = centerBoxChildren.findIndex(
	      c => c.child instanceof DateMenu.DateMenuButton ||
	           c instanceof DateMenu.DateMenuButton
	    );

	    if (dateMenuIndex !== -1 && position[index] === 'center') {
	      Main.panel.addToStatusArea(`${this.metadata.name} Indicator`, this._indicator, dateMenuIndex + qualifier[index], position[index]);
	    } else {
		  Main.panel.addToStatusArea(`${this.metadata.name} Indicator`, this._indicator, qualifier[index], position[index]);
	    }
	}

	previewDesktop(enable) {
		const workspace = global.workspace_manager.get_active_workspace();
		const windows = workspace.list_windows();
		const previewOpacity = Math.round((this._settings.get_int('hover-opacity') / 100) * 255);
		
		windows.forEach(w => {
			if (this._shouldIgnore(w)) return;
			let actor = w.get_compositor_private();
			if (actor) actor.opacity = enable ? previewOpacity : 255;
		});
	}

	toggleDesktop() {
		if (Main.overview.visible) return;
		const workspace = global.workspace_manager.get_active_workspace();
		const windows = workspace.list_windows();

		const validWindows = windows.filter(w => !this._shouldIgnore(w));
		const hasVisibleWindows = validWindows.some(w => !w.minimized);

		this.logDebug(`Toggle: valid windows count = ${validWindows.length}, hasVisibleWindows = ${hasVisibleWindows}`);

		if (hasVisibleWindows) {
			const focusedWindow = global.display.get_focus_window();
			const keepFocused = this._settings.get_boolean('keep-focused');
			
			validWindows.forEach(w => {
				if (keepFocused && w === focusedWindow) {
					this.logDebug(`Keeping focused window: ${w.get_title()}`);
					return;
				}
				w.minimize();
			});
		} else {
			this.logDebug("Unminimizing all valid windows");
			validWindows.forEach(w => w.unminimize());
		}
	}

	_shouldIgnore(window) {
		if (!window) return true;

		const title = window.get_title() ?? 'Unknown';
		const type = window.get_window_type();
		const wm_class = (window.get_wm_class() ?? '').toLowerCase();
		const focused = global.display.get_focus_window();

		if (window === focused && this._settings.get_boolean('keep-focused')) {
			this.logDebug(`Ignoring: ${title} (Focused)`);
			return true;
		}

		if (type === Meta.WindowType.DESKTOP || type === Meta.WindowType.DOCK || type === Meta.WindowType.MODAL_DIALOG) {
			this.logDebug(`Ignoring: ${title} (Type: ${type})`);
			return true;
		}

		if (window.is_skip_taskbar()) {
			this.logDebug(`Ignoring: ${title} (Skip Taskbar)`);
			return true;
		}

		if (wm_class.endsWith('notejot') || wm_class === 'conky' || wm_class === 'gjs') {
			this.logDebug(`Ignoring: ${title} (Specific class: ${wm_class})`);
			return true;
		}

		if (title.startsWith('@!') && (title.endsWith('BDH') || title.endsWith('BDHF'))) {
			this.logDebug(`Ignoring: ${title} (Special title pattern)`);
			return true;
		}

		return false;
	}

	disable() {
		this.logDebug("Extension Disabled");
		this.previewDesktop(false);
		this._signals.forEach(id => this._settings.disconnect(id));
		
		Main.wm.removeKeybinding('show-desktop-shortcut');

		if (this._indicator) {
			this._indicator.destroy();
			this._indicator = null;
		}
		this._settings = null;
		this._systemSettings = null;
	}
}
